<?php
	
	if(!defined ("INC")){
		
		header("location:index.php?information");
		exit;
	}
?>

<html>
Informations du site
</br>
</br>
</br>
Ce site a été développé dans le cadre d'un projet à but non lucratif afin d'aider l'alliance de la meute sur le jeu DOFUS.
</br>
</br>
Ce site est exclusivement destiné pour aider les membres de la guilde.
Cela vous permettra de localiser les portails vers les autres dimensions qui sont enregistré dans notre base de données, sur laquelle sont enregistré
les différentes informations contenu dans notre base de données sont privé, celle-ci ne seront pas utilisé ailleurs que sur notre site.
</html>