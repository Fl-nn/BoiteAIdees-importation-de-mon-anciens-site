<?php
	
	if(!defined ("INC")){
		
		header("location:index.php?condition");
		exit;
	}
?>
<html>
<h1>Conditions générales d'utilisation</h1>
</br>
</br>
 <p>			<img src='img/dofus.png' alt='dofus'/> Ce site est en plein travaux, veuilez signaler tous les bugs éventuels.<p>
</br>
Les données présentes sur le site ne seront pas utilisé ailleurs. Ce site n'est pas utilisé à des fin commercial. 

</html>
