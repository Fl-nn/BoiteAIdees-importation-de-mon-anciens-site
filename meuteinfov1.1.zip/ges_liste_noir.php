<?php
	if(!defined ("INC")){
		
		header("location:?ges_liste_noir");
		exit;
		
	}
	?>
		


<div class="ui-widget" align="center">
	<form class="form-inline" action='index.php?liste_noir' method='POST'>
		<p class='text-muted'>Recherchez un pseudonyme :<input id="recherche_liste_noir" type='text'  class="form-control" placeholder="Pseudonyme" name="personne_rechercher">	<input align="center" class="btn btn-xs btn-info-outline" type="submit" name="send" value="rechercher" /> <input align="center" class="btn-xs btn btn-info-outline" type="submit" name="que_les_banni" value="Afficher que les bannis"/></p>
	</form>
</div>
<br/>
<?php
if (isset($_POST['ban']) || isset($_POST['deban']))
{
	if (isset($_POST['ban']))
	{
		$ban=1;
	}
	else
	{
		$ban=0;
	}
	if (isset($_POST['tous'])) 
	{
		$req3 = $bdd->prepare('SELECT ID_Membres_Liee FROM  nom_personnage WHERE ID_Personnage=? ');
		$req3->execute(array($_POST['personne_selectionne']));
		while ( $donnees = $req3->fetch(PDO::FETCH_ASSOC ))
		{
			$req4 = $bdd->prepare('UPDATE nom_personnage SET Banni=?  WHERE ID_Membres_Liee=?');
			$req4->execute(array($ban,$donnees['ID_Membres_Liee']));
		}
		
	}
	else
	{
		$req2 = $bdd->prepare('UPDATE nom_personnage SET Banni=?  WHERE ID_Personnage=?');
		$req2->execute(array($ban,$_POST['personne_selectionne']));
	}
	echo '<div class="alert alert-success"><strong>Succes! </strong>La mise à jour est une reussite!<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></div>';
			
}
if (isset ($_POST['personne_rechercher']) && ($_POST['personne_rechercher']!="" )){
	$req = $bdd->query("SELECT ID_Personnage FROM nom_personnage WHERE  Pseudonyme LIKE '%".$_POST['personne_rechercher']."%' ORDER BY Pseudonyme ASC");
	if(count($req->fetchAll(PDO::FETCH_ASSOC)) == 0) {
		echo '<fieldset><legend>La recherche pour trouver "'.$_POST['personne_rechercher'].'" n\'a rien donné...</legend>';
			include("tout_ges_liste_noir.php");
		echo '</fieldset>';
	}
	else
	{
	$req = $bdd->query("SELECT ID_Personnage FROM nom_personnage WHERE  Pseudonyme LIKE'%".$_POST['personne_rechercher']."%' ORDER BY Pseudonyme ASC");

		echo '<fieldset><legend>Recherche de : '.$_POST['personne_rechercher'].'</legend>';
		echo '<table class="table table-striped">';
		$i=1;
		echo '<tr  class="success"><td></td><td>Nom du personnages</td><td>Niveau</td><td>Banni</td><td align="center">Appliquer aux personnages liés</td><td align="center"></td><td align="center"></td></tr>';
		while ( $donnees_joueur = $req->fetch() )
		{
			$blackliste = $bdd->query('SELECT * FROM nom_personnage WHERE ID_Personnage='.$donnees_joueur['ID_Personnage'].'');
			while ( $donnees = $blackliste->fetch(PDO::FETCH_ASSOC ))
			{
				echo '<form method="post" action ="index.php?liste_noir"><tr><td>'.$i.'</td>';
				echo '<td><ul class="nav navbar-nav">
            <li class="dropdown">
            	<a href="#" class="dropdown-toggle" data-toggle="dropdown">'.$donnees['Pseudonyme'].'<span class="caret"></span></a>
            	<ul class="dropdown-menu" role="menu">';
					echo '<li>Personnage(s) lié(s)</li>';
					echo '<li class="divider"></li>';
					$req3 = $bdd->query('SELECT Pseudonyme FROM  nom_personnage WHERE ID_Membres_Liee='.$donnees['ID_Membres_Liee'].' AND ID_Personnage<>'.$donnees['ID_Personnage'].' ');		
					while ( $donnees2 = $req3->fetch(PDO::FETCH_ASSOC ))
					{
					    echo '<li>'.$donnees2['Pseudonyme'].'</li>';
					}
				echo'</ul>
            </li>
        </ul>
				</td>';


				echo '<td>'.$donnees['Niveau'].'</td><td>';if($donnees['Banni']==0){echo 'Non banni';}else{echo 'Banni';}echo'</td><td align="center"><input type="checkbox" name="tous"/></td><td align="center"></td><td align="center"><input type="hidden" name="personne_selectionne" value="'.$donnees['ID_Personnage'].'" /> ';if($donnees['Banni']==0){echo '<input class="btn btn-danger btn-s btn-block" type="submit"  name="ban" value="        Bannir        "/>';}else{echo '<input class="btn btn-info btn-s btn-block" type="submit" name="deban" value="Ne plus bannir"/>';}echo '</td></tr></form>';
				$i++;
			}		
		}
		
			echo '</table>';
			echo '</fieldset>';
	}
	
}
elseif( isset($_POST['que_les_banni'])){
	
	$blackliste = $bdd->query('SELECT * FROM nom_personnage WHERE Banni=1');
	if(count($blackliste->fetchAll()) == 0) {
		echo '<fieldset><legend>Il n\'y a personne de banni.</legend>';
		include("tout_ges_liste_noir.php");
		echo '</fieldset>';
	}
	else{
		echo '<fieldset><legend>Liste des bannis</legend>';
		echo '<table class="table table-striped">';
		$i=1;
		echo '<tr  class="success"><td></td><td>Nom du personnages</td><td>Niveau</td><td>Banni</td><td align="center">Appliquer aux personnages liés</td><td align="center"></td><td align="center"></td></tr>';
		$blackliste = $bdd->query('SELECT * FROM nom_personnage WHERE Banni=1');
		while ( $donnees = $blackliste->fetch(PDO::FETCH_ASSOC ))
		{
		echo '<form method="post" action ="index.php?liste_noir"><tr><td>'.$i.'</td>';
		echo '<td><ul class="nav navbar-nav">
            <li class="dropdown">
            	<a href="#" class="dropdown-toggle" data-toggle="dropdown">'.$donnees['Pseudonyme'].'<span class="caret"></span></a>
            	<ul class="dropdown-menu" role="menu">';
					echo '<li>Personnage(s) lié(s)</li>';
					echo '<li class="divider"></li>';
					$req3 = $bdd->query('SELECT Pseudonyme FROM  nom_personnage WHERE ID_Membres_Liee='.$donnees['ID_Membres_Liee'].' AND ID_Personnage<>'.$donnees['ID_Personnage'].' ');		
					while ( $donnees2 = $req3->fetch(PDO::FETCH_ASSOC ))
					{
					    echo '<li>'.$donnees2['Pseudonyme'].'</li>';
					}
				echo'</ul>
            </li>
        </ul>
				</td><td>'.$donnees['Niveau'].'</td>';

		echo'<td>';if($donnees['Banni']==0){echo 'Non banni';}else{echo 'Banni';}echo'</td><td align="center"><input type="checkbox" name="tous"/></td><td align="center"></td><td align="center"><input type="hidden" name="personne_selectionne" value="'.$donnees['ID_Personnage'].'" /> ';if($donnees['Banni']==0){echo '<input class="btn btn-danger btn-s btn-block" type="submit"  name="ban" value="        Bannir        "/>';}else{echo '<input class="btn btn-info btn-s btn-block" type="submit" name="deban" value="Ne plus bannir"/>';}echo '</td></tr></form>';
			$i++;
		}	

		echo '</table>';
		echo '</fieldset>';
	}
				
	
}
else{

	echo '<fieldset><legend>Liste des personnages enregistré dans la base</legend>';
		include("tout_ges_liste_noir.php");
	echo '</fieldset>';
}
include('add_nouveau_blackliste.php');
?>
