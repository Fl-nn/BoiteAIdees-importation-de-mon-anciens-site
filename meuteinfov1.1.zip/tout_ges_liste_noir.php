<?php
	if(!defined ("INC")){
		
		header("location:index.php");
		exit;
	}
?>
<?php
	echo '<table class="table table-striped">';
	$i=1;
	echo '<tr  class="success"><td></td><td>Nom du personnages</td><td>Niveau</td><td>Banni</td><td align="center">Appliquer aux personnages liés</td><td align="center"></td><td align="center"></td></tr>';
	
		$blackliste = $bdd->query('SELECT * FROM nom_personnage');
		while ( $donnees = $blackliste->fetch(PDO::FETCH_ASSOC ))
		{
			echo '<form method="post" action ="index.php?liste_noir"><tr><td>'.$i.'</td>';
			echo '<td><ul class="nav navbar-nav">
            <li class="dropup">
            	<a href="#" class="dropdown-toggle" data-toggle="dropdown">'.$donnees['Pseudonyme'].'<span class="caret"></span></a>
            	<ul class="dropdown-menu" role="menu">';
					echo '<li>Personnage(s) lié(s)</li>';
					echo '<li class="divider"></li>';
					$req3 = $bdd->query('SELECT Pseudonyme FROM  nom_personnage WHERE ID_Membres_Liee='.$donnees['ID_Membres_Liee'].' AND ID_Personnage<>'.$donnees['ID_Personnage'].' ');		
					while ( $donnees2 = $req3->fetch(PDO::FETCH_ASSOC ))
					{
					    echo '<li>'.$donnees2['Pseudonyme'].'</li>';
					}
				echo'</ul>
            </li>
        </ul>
				</td>';


			echo '<td>'.$donnees['Niveau'].'</td><td>';if($donnees['Banni']==0){echo 'Non banni';}else{echo 'Banni';}echo'</td><td align="center"><input type="checkbox" name="tous"/></td><td align="center"></td><td align="center"><input type="hidden" name="personne_selectionne" value="'.$donnees['ID_Personnage'].'" /> ';if($donnees['Banni']==0){echo '<input class="btn btn-danger btn-s btn-block" type="submit"  name="ban" value="        Bannir        "/>';}else{echo '<input class="btn btn-info btn-s btn-block" type="submit" name="deban" value="Ne plus bannir"/>';}echo '</td></tr></form>';
			$i++;
		}		
	
	
		echo '</table>';