<?php
	include ("connexion_bd.php");

$searchTerm = $_GET['term'];
//'SELECT * FROM nom_personnage WHERE Pseudonyme LIKE
$statement = $bdd->query("SELECT * FROM nom_personnage WHERE Pseudonyme LIKE '%".$searchTerm."%' ORDER BY Pseudonyme ASC");


while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
    $data[] = $row['Pseudonyme'];
}
echo json_encode($data);
?>